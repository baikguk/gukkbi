package com.jsb_home.security;


import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class Security extends WebSecurityConfigurerAdapter {

  //Ctrl+ o -> 오버라이드 가능한 목록

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.authorizeRequests().mvcMatchers("/","/login","/sign-up",
        "/check-email","/check-email-token","/check-email-login","/login-link")
      .permitAll().mvcMatchers(HttpMethod.GET,"/profile/*").permitAll()
      //  ㄴ get 방식일때만 "/profile/*" 허용
      .anyRequest()
      .authenticated();
  }

  @Override
  public void configure(WebSecurity web) throws Exception {//이미지가 잘나오게 허용
    web.ignoring()
      .requestMatchers(PathRequest.toStaticResources().atCommonLocations());
  }
}
