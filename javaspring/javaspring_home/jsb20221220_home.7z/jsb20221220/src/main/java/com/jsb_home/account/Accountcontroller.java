package com.jsb_home.account;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Accountcontroller {

  @GetMapping("/sign-up")
  // 주소 표시에서 /sign-up을 가져옴
  // Spring FrameWork가 @GetMapping("/sign-up")을 인식하여
  // AccountController 클래스의 signUpFrom(Model model) 메소드가 자동으로 호출됨

  //  //GetMapping으로 /sign-up을 받게 되면 자동으로 호출하여 실행됨
  public String signUpForm(Model model){

    //account.signup으로 이동할때 ,SignUpForm 객체 생성
    //signUpForm이라는 변수에 할당해서 넘김
    // model이 이름 signUpform 타입(SignUpForm) 객체를 생성해서 메모리에 올려줌
    // 이후 sign-up-description html에서 메모리에 올라와있는  signUpform 객체를 받아서 씀
    model.addAttribute("signUpForm", new signupform());


    return "account/sign-up-home";
    // 자동으로 template 폴더에 연결하여 해당 return값의 주소로감
    // 해당 주소에 있는건 html임으로 페이지가 해당 html을 출력

    /*
    *   Sign Up Page 입니다
  <br>경로 : templates/account/sign-up.html
  <br> @GetMapping("/sign-up")이 주소에서 /sign-up을 가져옴
  <br> Spring FrameWork가 @GetMapping("/sign-up")을 인식하여
  <br> AccountController 클래스의 signUpFrom(Model model) 메소드가 자동으로 호출됨

  <br>public String signUpForm(Model model){
  <br>return "account/sign-up";
  <br>GetMapping으로 /sign-up을 받게 되면 자동으로 호출하여 실행됨
  <br>자동으로 template 폴더에 연결하여 해당 return값의 주소로감
  <br>해당 주소에 있는건 html임으로 페이지가 해당 html을 출력
</body>
    * */
  }
}
