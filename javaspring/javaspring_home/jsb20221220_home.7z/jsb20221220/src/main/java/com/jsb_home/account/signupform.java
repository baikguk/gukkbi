package com.jsb_home.account;


import lombok.Data;

@Data
public class signupform {
  private String nickname;
  private String email;
  private String password;
}
