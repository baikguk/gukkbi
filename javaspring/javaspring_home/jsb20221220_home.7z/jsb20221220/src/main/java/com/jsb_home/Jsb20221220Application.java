package com.jsb_home;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jsb20221220Application {

  public static void main(String[] args) {
    SpringApplication.run(Jsb20221220Application.class, args);
  }

}
