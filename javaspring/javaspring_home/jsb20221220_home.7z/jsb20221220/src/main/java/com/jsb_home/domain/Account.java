package com.jsb_home.domain;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter @Setter @EqualsAndHashCode(of="id")
@Builder @AllArgsConstructor
@NoArgsConstructor
public class Account {
  @Id
  private Long id;

  @Column(unique = true)
  private String email;

  @Column(unique = true)
  private String nickname;

  private String passwork;

  private boolean emailVerified;

  private String emailCheckToken;

  private LocalDateTime joinAt;

  private String bio;

  private String url;

  private String occupation;

  private String location;

  @Lob @Basic(fetch = FetchType.EAGER)
  private String profileImage;

  private boolean studyCreateEmail;

  private boolean studyCreateByWeb;

  private boolean studyEnrollmentResultByEmail;

  private boolean studyEnrollmentResultByWeb;

  private boolean studyUpdateResultByEmail;

  private boolean studyUpdateResultByWeb;
}
