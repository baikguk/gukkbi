package com.jsb_home;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jsb20221220ApplicationTests {

  @Test
  void contextLoads() {
  }

}
