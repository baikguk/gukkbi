package com.global;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Js20221219ApplicationTests {

	@Test
	void contextLoads() {
	}

}
